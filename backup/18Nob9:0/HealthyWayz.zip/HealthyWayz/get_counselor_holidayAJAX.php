
<?php 

include "includes/config.php";
$sql = "SELECT *  FROM counsller where id =".$_POST['id'];
if($res = $conn->query($sql)){
    
$php_data_array = Array(); 
   while($row = $res->fetch_assoc()) {
      
        $php_data_array[] = $row['holiday']; // Adding to array
        $data = $row['holiday'];
        echo $data;
       
   }
} 

?>


                                                