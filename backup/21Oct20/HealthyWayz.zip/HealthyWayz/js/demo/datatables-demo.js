// Call the dataTables jQuery plugin
$(document).ready(function() {
  $('#dataTable').DataTable();
    $("thead").addClass("table-primary");
   // $("tfoot").addClass("table-primary");
   $('#dataTable1').DataTable({
        paging: false,
         ordering: false,
   });
    $('#dataTable2').DataTable({
        paging: false,
         ordering: false,
   });
    $("thead").addClass("table-primary");
});

// Call the dataTables jQuery plugin
$(document).ready(function() {
  $('#example').DataTable( {
  //"pageLength": 50
  paging: false,
  ordering: false,
} );
});
